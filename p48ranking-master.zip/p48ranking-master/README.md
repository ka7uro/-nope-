[Produce 48 Rankings](https://ajyu124.github.io/p48ranking/)

An interactive ranking chart for MNet's Produce 48 made with d3.js. I updated this website after each episode as the season progressed.

![alt text](Produce_48.jpg "Screenshot")
